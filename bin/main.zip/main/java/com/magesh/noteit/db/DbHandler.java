package com.magesh.noteit.db;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.magesh.noteit.models.Note;

import java.util.ArrayList;
import java.util.List;

public class DbHandler extends SQLiteOpenHelper{
    private static final int DATABASE_VERSION = 1;

    private static final String DATABASE_NAME = "noteIt";

    private static final String TABLE_NOTES = "notes";

    private static final String NOTES_ID = "id";
    private static final String NOTES_TITLE = "title";
    private static final String NOTES_NOTE = "note";
    private static final String NOTES_STATUS = "status";
    private static final String NOTES_CREATED_AT = "created_at";

    public DbHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String CREATE_NOTES_TABLE = "CREATE TABLE " + TABLE_NOTES + " ( "
                + NOTES_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + NOTES_TITLE + " TEXT,"
                + NOTES_NOTE + " TEXT, " + NOTES_STATUS + " INTEGER, " + NOTES_CREATED_AT + " INTEGER )";
//        String CREATE_NOTES_TABLE = "CREATE TABLE ? ( ? INTEGER PRIMARY KEY AUTOINCREMENT, ? TEXT, ? TEXT, ? INTEGER, ? INTEGER)";
//        Object[] bindArgs = new Object[]{TABLE_NOTES, NOTES_ID, NOTES_TITLE, NOTES_NOTE, NOTES_STATUS, NOTES_CREATED_AT};
        sqLiteDatabase.execSQL(CREATE_NOTES_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NOTES);
        onCreate(sqLiteDatabase);
    }

    public void addNote(Note note){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(NOTES_TITLE, note.getTitle());
        values.put(NOTES_NOTE, note.getNote());
        values.put(NOTES_STATUS, note.getStatus());
        values.put(NOTES_CREATED_AT, note.getCreated_at());

        db.insert(TABLE_NOTES, null, values);
        db.close();
    }

    public Note getNote(int id){
        String selectQuery = "SELECT * FROM " + TABLE_NOTES + " WHERE ID = " + id;
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        cursor.moveToFirst();
        Note note = new Note();
        note.set_id(cursor.getInt(0));
        note.setTitle(cursor.getString(1));
        note.setNote(cursor.getString(2));
        note.setStatus(cursor.getInt(3));
        note.setCreated_at(cursor.getInt(4));
        cursor.close();

        return note;
    }

    public List<Note> getAllNotes(int status){
        List<Note> notesList = new ArrayList<>();

        String selectQuery = "SELECT * FROM " + TABLE_NOTES + " WHERE " + NOTES_STATUS + " = " + status + " ORDER BY " + NOTES_ID +" DESC";

        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if(cursor.moveToFirst()){
            do {
                Note note = new Note();
                note.set_id(cursor.getInt(0));
                note.setTitle(cursor.getString(1));
                note.setNote(cursor.getString(2));
                note.setStatus(cursor.getInt(3));
                note.setCreated_at(cursor.getInt(4));
                notesList.add(note);
            }while (cursor.moveToNext());
        }
        cursor.close();

        return notesList;
    }

    public void deleteNotePermanent(Note note){
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_NOTES, NOTES_ID + " = ?",
                new String[] { String.valueOf(note.get_id()) });
        db.close();
    }

    public int deleteNote(Note note){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NOTES_STATUS, 0);

        return db.update(TABLE_NOTES, values, NOTES_ID + " = ?",
                new String[] { String.valueOf(note.get_id()) });
    }

    public int restoreNote(Note note){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NOTES_STATUS, 1);

        return db.update(TABLE_NOTES, values, NOTES_ID + " = ?",
                new String[] { String.valueOf(note.get_id()) });
    }

    public int updateNote(Note note){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(NOTES_TITLE, note.getTitle());
        values.put(NOTES_NOTE, note.getNote());

        return db.update(TABLE_NOTES, values, NOTES_ID + " = ?",
                new String[] { String.valueOf(note.get_id()) });
    }

    public int getNotesCount() {
        String countQuery = "SELECT  * FROM " + TABLE_NOTES;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();
        return cursor.getCount();
    }
}
