package com.magesh.noteit;

import android.content.Context;
import android.graphics.Color;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.magesh.noteit.models.Note;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
    private Context context;
    private List<Note> notes;
    private SparseBooleanArray selectedIds;

    public RecyclerAdapter(Context context, List<Note> notes) {
        this.context = context;
        this.notes = notes;
        selectedIds = new SparseBooleanArray();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Note note = notes.get(position);
        holder.title.setText(note.getTitle());
        holder.note.setText(note.getNote());
        if(isSelected(position)) {
            ((CardView) holder.itemView).setCardBackgroundColor(ContextCompat.getColor(context, R.color.primary_light));
        } else {
            ((CardView) holder.itemView).setCardBackgroundColor(Color.WHITE);
        }
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public int getSelectedCount(){
        return selectedIds.size();
    }

    public boolean isSelected(int position){
        return selectedIds.get(position);
    }

    public void removeSelection(){
        selectedIds.clear();
        notifyDataSetChanged();
    }

    public SparseBooleanArray getAllSelections(){
        return selectedIds;
    }

    public void toggleSelection(int position){
        selectView(position, !selectedIds.get(position));
    }

    public void selectView(int position, boolean value){
        if(value) selectedIds.put(position, value);
        else selectedIds.delete(position);
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView title;
        TextView note;

        public ViewHolder(View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.note_title);
            note = (TextView) itemView.findViewById(R.id.note_content);
        }
    }
}
