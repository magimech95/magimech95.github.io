package com.magesh.noteit;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.magesh.noteit.models.Note;

public class ColorDialogAdapter extends RecyclerView.Adapter<ColorDialogAdapter.ViewHolder> {
    private String[] colorsArray;

    public ColorDialogAdapter(String[] colorsArray) {
        this.colorsArray = colorsArray;
    }

    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.color_card_view, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
//        CardView cardView = (CardView) holder.itemView;
//        cardView.setCardBackgroundColor(Color.parseColor(colorsArray[position]));
        ImageView imageView = (ImageView) holder.itemView;
        Drawable background = imageView.getBackground();
        if (background instanceof ShapeDrawable) {
            ((ShapeDrawable)background).getPaint().setColor(Color.parseColor(colorsArray[position]));
        } else if (background instanceof GradientDrawable) {
            ((GradientDrawable)background).setColor(Color.parseColor(colorsArray[position]));
        } else if (background instanceof ColorDrawable) {
            ((ColorDrawable)background).setColor(Color.parseColor(colorsArray[position]));
        }//        imageView.setBackgroundColor(Color.parseColor(colorsArray[position]));
    }

    @Override
    public int getItemCount() {
        return colorsArray.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public ViewHolder(View itemView) {
            super(itemView);

        }
    }
}
