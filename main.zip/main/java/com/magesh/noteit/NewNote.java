package com.magesh.noteit;


import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.NavUtils;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;

import com.magesh.noteit.db.DbHandler;
import com.magesh.noteit.models.Note;


public class NewNote extends AppCompatActivity {
    private EditText note_title;
    private EditText note;
    private Note update_note;
    private DbHandler dbHandler;
    private int status = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_note);
        Toolbar toolbar = (Toolbar) findViewById(R.id.new_note_toolbar);
        note_title = (EditText) findViewById(R.id.new_note_title);
        note = (EditText) findViewById(R.id.new_note_content);

        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }


        dbHandler = new DbHandler(this);

        Intent intent = this.getIntent();
        if(intent.hasExtra("ID")){
            Bundle extras = intent.getExtras();
            update_note = dbHandler.getNote(extras.getInt("ID"));
            note_title.setText(update_note.getTitle());
            note.setText(update_note.getNote());
            status = extras.getInt("STATUS");
        }

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.note_save_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveNote();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.new_note, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.note_delete){
            if(update_note!=null){
                if(status==1) dbHandler.deleteNote(update_note);
                else dbHandler.deleteNotePermanent(update_note);
            }
            NavUtils.navigateUpFromSameTask(this);
        }
        return super.onOptionsItemSelected(item);
    }

    public void saveNote(){
        if(update_note!=null){
            update_note.setTitle(note_title.getText().toString());
            update_note.setNote(note.getText().toString());
            dbHandler.updateNote(update_note);
        }
        else {
            Note new_note = new Note();
            new_note.setTitle(note_title.getText().toString());
            new_note.setNote(note.getText().toString());
            new_note.setStatus(1);
            new_note.setCreated_at(System.currentTimeMillis());
            dbHandler.addNote(new_note);
        }

        NavUtils.navigateUpFromSameTask(this);
    }
}
