package com.magesh.noteit;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.widget.ImageView;

public class ColorPaletteDialog extends DialogFragment {
    private OnColorPickListener listener;

    public interface OnColorPickListener{
        public abstract void onColorPick(int color);
    }

    public ColorPaletteDialog() {
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.color_palette);

        String[] colorsArray = getActivity().getResources().getStringArray(R.array.color_palette);
        ColorDialogAdapter colorDialogAdapter = new ColorDialogAdapter(colorsArray);
        RecyclerView colorView = (RecyclerView) dialog.findViewById(R.id.color_view);
        StaggeredGridLayoutManager colorLayoutManager = new StaggeredGridLayoutManager(5,1);
        colorLayoutManager.setGapStrategy(StaggeredGridLayoutManager.GAP_HANDLING_MOVE_ITEMS_BETWEEN_SPANS);
        colorView.setLayoutManager(colorLayoutManager);
        colorView.setAdapter(colorDialogAdapter);

        colorView.addOnItemTouchListener(new ContentFragment.RecyclerItemClickListener(getContext(), colorView, new ContentFragment.RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                listener.onColorPick(position);
                dismiss();
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));
        return dialog;
    }

    public void setListener(OnColorPickListener listener){
        this.listener = listener;
    }

}

