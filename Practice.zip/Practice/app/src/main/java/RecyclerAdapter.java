import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.magesh.practice.R;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
    private String[] Dataset;

    public static class ViewHolder extends RecyclerView.ViewHolder{
        TextView card_text;
        public ViewHolder(View view){
            super(view);
            card_text = (TextView) view.findViewById(R.id.card_text);
        }
    }

    public RecyclerAdapter(String[] dataset){
        Dataset = dataset;
    }

    @Override
    public RecyclerAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card, parent, false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.card_text.setText(Dataset[position]);
    }

    @Override
    public int getItemCount() {
        return Dataset.length;
    }
}
